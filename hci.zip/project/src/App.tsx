import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line, PieChart, Pie, Cell, RadialBarChart, RadialBar } from 'recharts';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Calendar, 
  Users, 
  Settings, 
  Bell, 
  Search,
  ChevronRight,
  CircleUserRound,
  LogOut,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp
} from 'lucide-react';

// Sample data for charts
const pendingTasks = [
  { name: 'Critical', value: 12, color: '#7C3AED' },
  { name: 'High', value: 8, color: '#2563EB' },
  { name: 'Medium', value: 5, color: '#059669' },
];

const performanceData = [
  { name: 'Jan', completion: 65, target: 60 },
  { name: 'Feb', completion: 75, target: 65 },
  { name: 'Mar', completion: 85, target: 70 },
  { name: 'Apr', completion: 82, target: 75 },
  { name: 'May', completion: 90, target: 80 },
];

const completedTasks = [
  { name: 'Q1', innovations: 28, operations: 22, strategy: 18 },
  { name: 'Q2', innovations: 32, operations: 25, strategy: 22 },
  { name: 'Q3', innovations: 35, operations: 28, strategy: 24 },
  { name: 'Q4', innovations: 40, operations: 30, strategy: 28 },
];

const notificationsData = [
  { name: 'Mentions', value: 20, fill: '#8B5CF6' },
  { name: 'Meetings', value: 15, fill: '#3B82F6' },
  { name: 'Deadlines', value: 10, fill: '#10B981' },
  { name: 'Updates', value: 25, fill: '#6366F1' },
];

const quickStats = [
  {
    title: 'Completed Tasks',
    value: 248,
    change: '+12%',
    icon: CheckCircle2,
    color: 'emerald',
  },
  {
    title: 'In Progress',
    value: 45,
    change: '+5%',
    icon: Clock,
    color: 'blue',
  },
  {
    title: 'Overdue',
    value: 8,
    change: '-2%',
    icon: AlertCircle,
    color: 'rose',
  },
  {
    title: 'Efficiency Rate',
    value: '94%',
    change: '+8%',
    icon: TrendingUp,
    color: 'violet',
  },
];

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [hoveredChart, setHoveredChart] = useState<string | null>(null);

  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'chat', icon: MessageSquare, label: 'Communications' },
    { id: 'calendar', icon: Calendar, label: 'Schedule' },
    { id: 'team', icon: Users, label: 'Team' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  const chartVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const cardVariants = {
    hover: {
      scale: 1.02,
      transition: { duration: 0.2 }
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-slate-200 shadow-lg">
        <div className="flex items-center justify-between px-6 h-16 border-b border-slate-200 bg-gradient-to-r from-indigo-600 to-blue-500">
          <div className="flex items-center space-x-3">
            <span className="text-xl font-bold text-white">WorkPlan</span>
          </div>
        </div>
        
        <div className="px-4 py-6">
          <nav className="space-y-1">
            {menuItems.map((item) => (
              <motion.button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-indigo-50 to-blue-50 text-indigo-700'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <item.icon className={`h-5 w-5 mr-3 ${
                  activeTab === item.id ? 'text-indigo-600' : 'text-slate-500'
                }`} />
                {item.label}
              </motion.button>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 w-64 border-t border-slate-200">
          <div className="px-6 py-4">
            <div className="flex items-center space-x-3">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="relative"
              >
                <img
                  src="https://api.dicebear.com/7.x/bottts/svg?seed=KC&backgroundColor=indigo&eyes=happy"
                  alt="Kishore Chakraborty"
                  className="h-12 w-12 rounded-full border-2 border-indigo-200 shadow-lg hover:border-indigo-300 transition-all duration-200"
                />
                <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></div>
              </motion.div>
              <div>
                <p className="text-sm font-medium text-slate-700">Kishore Chakraborty</p>
                <p className="text-xs text-slate-500">Project Plan</p>
              </div>
            </div>
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="mt-4 flex items-center text-sm text-slate-700 hover:text-slate-900 transition-colors"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </motion.button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 shadow-sm">
          <div className="flex items-center justify-between px-8 h-16">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <Bell className="h-5 w-5 text-slate-600" />
              </motion.button>
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-indigo-600 to-blue-500 flex items-center justify-center">
                <span className="text-white text-sm font-medium">KC</span>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-8">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={chartVariants}
            className="mb-8"
          >
            <h1 className="text-2xl font-bold text-slate-900">Executive Dashboard</h1>
            <p className="text-slate-600">Real-time insights and performance metrics</p>
          </motion.div>

          {/* Quick Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {quickStats.map((stat, index) => (
              <motion.div
                key={stat.title}
                variants={cardVariants}
                whileHover="hover"
                className={`bg-white rounded-xl shadow-lg border border-${stat.color}-100 p-6 hover:shadow-xl transition-all duration-300`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600">{stat.title}</p>
                    <h3 className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</h3>
                    <p className={`text-sm text-${stat.color}-600 mt-1`}>
                      {stat.change} from last month
                    </p>
                  </div>
                  <div className={`p-3 bg-${stat.color}-100 rounded-lg`}>
                    <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Priority Distribution */}
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={chartVariants}
              whileHover={{ scale: 1.02 }}
              onHoverStart={() => setHoveredChart('priority')}
              onHoverEnd={() => setHoveredChart(null)}
              className="bg-white rounded-xl shadow-lg border border-slate-200 p-4 hover:shadow-xl transition-all duration-300"
            >
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Priority Distribution</h2>
              <PieChart width={200} height={200}>
                <Pie
                  data={pendingTasks}
                  cx={100}
                  cy={100}
                  innerRadius={30}
                  outerRadius={hoveredChart === 'priority' ? 60 : 50}
                  paddingAngle={5}
                  dataKey="value"
                  animationBegin={0}
                  animationDuration={1500}
                >
                  {pendingTasks.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </motion.div>

            {/* Performance Metrics */}
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={chartVariants}
              whileHover={{ scale: 1.02 }}
              onHoverStart={() => setHoveredChart('performance')}
              onHoverEnd={() => setHoveredChart(null)}
              className="bg-white rounded-xl shadow-lg border border-slate-200 p-4 hover:shadow-xl transition-all duration-300"
            >
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Performance</h2>
              <LineChart width={200} height={200} data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="completion" 
                  stroke="#4f46e5" 
                  strokeWidth={hoveredChart === 'performance' ? 3 : 2}
                  dot={{ fill: '#4f46e5' }}
                  animationDuration={1500}
                />
                <Line 
                  type="monotone" 
                  dataKey="target" 
                  stroke="#10B981" 
                  strokeWidth={hoveredChart === 'performance' ? 3 : 2}
                  dot={{ fill: '#10B981' }}
                  animationDuration={1500}
                />
              </LineChart>
            </motion.div>

            {/* Notifications Dashboard */}
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={chartVariants}
              whileHover={{ scale: 1.02 }}
              onHoverStart={() => setHoveredChart('notifications')}
              onHoverEnd={() => setHoveredChart(null)}
              className="bg-white rounded-xl shadow-lg border border-slate-200 p-4 hover:shadow-xl transition-all duration-300 col-span-2"
            >
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Notifications Overview</h2>
              <RadialBarChart 
                width={400} 
                height={200} 
                innerRadius="30%" 
                outerRadius={hoveredChart === 'notifications' ? '95%' : '90%'}
                data={notificationsData} 
                startAngle={0} 
                endAngle={360}
              >
                <RadialBar
                  minAngle={15}
                  background
                  clockWise={true}
                  dataKey="value"
                  animationBegin={0}
                  animationDuration={1500}
                  label={{ fill: '#666', position: 'insideStart' }}
                />
                <Tooltip />
                <Legend iconSize={10} layout="vertical" verticalAlign="middle" align="right" />
              </RadialBarChart>
            </motion.div>
          </div>

          {/* Large Completed Tasks Overview */}
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={chartVariants}
            whileHover={{ scale: 1.01 }}
            onHoverStart={() => setHoveredChart('completed')}
            onHoverEnd={() => setHoveredChart(null)}
            className="bg-white rounded-xl shadow-lg border border-slate-200 p-6 hover:shadow-xl transition-all duration-300"
          >
            <h2 className="text-lg font-semibold text-slate-900 mb-6">Completed Work Overview</h2>
            <BarChart width={1000} height={300} data={completedTasks}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip />
              <Legend />
              <Bar 
                dataKey="innovations" 
                name="Innovations" 
                fill="#4F46E5" 
                animationDuration={1500}
                radius={[4, 4, 0, 0]}
              />
              <Bar 
                dataKey="operations" 
                name="Operations" 
                fill="#2563EB" 
                animationDuration={1500}
                radius={[4, 4, 0, 0]}
              />
              <Bar 
                dataKey="strategy" 
                name="Strategy" 
                fill="#7C3AED" 
                animationDuration={1500}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </motion.div>
        </main>
      </div>
    </div>
  );
}

export default App;